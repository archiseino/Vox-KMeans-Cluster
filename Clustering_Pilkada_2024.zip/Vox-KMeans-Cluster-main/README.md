## Hi mate, this is the part of my KP Repository at KPU Provinsi Lampung

Let's make it short.
This analysis using K-Means clustering on the combine dataset of the data rekapitulasi daftar pemilh dan data tambahan dari BPS Provinsi Lampung.

Result: It was not was I expecting, since the nature of the data is have low standar variation, the data is groupped in one cluster and it's hard to visualize the data.

I wonder if I've another importatnt dataset such as age distribution, income, and education rate. Probably the result will be different
